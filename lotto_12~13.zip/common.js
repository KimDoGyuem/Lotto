function dw(x){
    document.write(x);
}
function br(){
    document.write("<br>");
}